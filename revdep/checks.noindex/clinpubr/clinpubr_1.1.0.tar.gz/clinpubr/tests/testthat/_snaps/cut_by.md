# cut_by handles quantile breaks

    Code
      res
    Output
        [1] A A b A A b b A A A b b b A A b b A b A A A A A A A b A A b b A b b b b b
       [38] A A A A A A b b A A A b A b A A b A b A b A A b A A A A b b A b b A A b A
       [75] A b A A A A A b A b A b b b A b b b b A b A b b A A
      Levels: A b

