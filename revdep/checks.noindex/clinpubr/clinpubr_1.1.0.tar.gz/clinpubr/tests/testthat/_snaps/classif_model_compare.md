# save_output=FALSE suppresses file generation

    Code
      res$metric_table
    Output
        Model                  AUC PRAUC Accuracy Sensitivity Specificity
      1 model 0.474 (0.359, 0.589) 0.456     0.55       0.149       0.906
        Pos Pred Value Neg Pred Value    F1 Kappa Brier cutoff Youden HosLem
      1          0.583          0.545 0.237 0.057 0.331  0.891  0.055      0

