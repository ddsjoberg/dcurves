# rcs_plot finds best knots

    Code
      result$aics
    Output
      [1] 269.6667 270.2421 269.3772 271.2359 272.7613

# rcs_plot returns details when requested

    Code
      details_no_plot
    Output
      $aics
      NULL
      
      $knot
      [1] 4
      
      $n.valid
      [1] 228
      
      $n.plot
      [1] 217
      
      $phassump
      NULL
      
      $phresidual
      NULL
      
      $pvalue_all
      [1] 0.0996151
      
      $pvalue_nonlin
      [1] 0.4849261
      
      $ref
      [1] 63
      

