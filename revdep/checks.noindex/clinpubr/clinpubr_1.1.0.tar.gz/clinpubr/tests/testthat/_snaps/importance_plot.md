# importance_plot works with top_n and split_at

    Code
      p$data
    Output
             name       value   label
      var18 var18 0.960180306 9.6e-01
      var7   var7 0.752337533 7.5e-01
      var4   var4 0.617911266 6.2e-01
      var6   var6 0.585226232 5.9e-01
      var20 var20 0.284020045 2.8e-01
      var15 var15 0.270399802 2.7e-01
      var17 var17 0.190312869 1.9e-01
      var13 var13 0.153057952 1.5e-01
      var8   var8 0.125991985 1.3e-01
      var9   var9 0.098547793 9.9e-02
      var3   var3 0.061690365 6.2e-02
      var16 var16 0.030537600 3.1e-02
      var14 var14 0.008360698 8.4e-03
      var19 var19 0.007927185 7.9e-03
      var2   var2 0.007135720 7.1e-03
      var1    ...          NA     ...

