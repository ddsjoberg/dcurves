#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom graphics abline
#' @importFrom graphics legend
#' @importFrom graphics lines
#' @importFrom graphics matplot
#' @importFrom grDevices grey
#' @importFrom methods is
#' @importFrom stats loess
#' @importFrom stats predict
#' @importFrom stats quantile
## usethis namespace: end
NULL
